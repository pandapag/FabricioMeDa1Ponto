from flask import Flask, request, render_template, redirect, url_for, jsonify
import mysql.connector

bot = Flask(__name__)

db_config = mysql.connector.connect(
    host='localhost',
    user='root',
    password='12345678',
    database='aula_13_10'
)

cursor = db_config.cursor()

@bot.route('/')
def index():
    return render_template('index.html')

@bot.route('/setor', methods=['POST'])
def setor():
    if request.method == 'POST':
        nome = request.form['nome']
        cursor.execute('INSERT INTO setor (nome) VALUES (%s)', (nome, ))
        db_config.commit()
    return redirect(url_for('index'))

@bot.route('/funcionario', methods=['POST'])
def funcionario():
    if request.method == 'POST':
        try:
            primeiro_nome = request.form['primeiro_nome']
            sobrenome = request.form['sobrenome']
            data_admissao = request.form['data_admissao']
            status_funcionario = request.form['status_funcionario']
            id_setor = request.form['id_setor']
            id_cargo = request.form['id_cargo']
            cursor.execute('INSERT INTO funcionarios (primeiro_nome, sobrenome, data_admissao, status_funcionario, id_setor, id_cargo) VALUES (%s, %s, %s, %s, %s, %s)',
            (primeiro_nome, sobrenome, data_admissao, status_funcionario, id_setor, id_cargo))
            db_config.commit()
            return jsonify({'message': 'Funcionário cadastrado com sucesso!'})
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    return redirect(url_for('index'))


@bot.route('/cargo', methods=['POST'])
def cargo():
    if request.method == 'POST':
        nome_cargo = request.form['nome_cargo']
        id_setor_cargo = request.form['id_setor_cargo']
        cursor.execute('INSERT INTO cargos (nome, setor_id) VALUES (%s, %s)',
                       (nome_cargo, id_setor_cargo))
        db_config.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    bot.run()