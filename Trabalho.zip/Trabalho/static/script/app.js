window.addEventListener('DOMContentLoaded', (event) => {
  let currentFormIndex = 0;
  const forms = document.querySelectorAll('.form-section');
  forms[currentFormIndex].classList.add('active');

  const showForm = (index) => {
    forms[currentFormIndex].classList.remove('active');
    forms[index].classList.add('active');
    currentFormIndex = index;
  };

  document.getElementById('add-sector').addEventListener('click', () => {
    
    showForm(1); 
  });

  document.getElementById('add-position').addEventListener('click', () => {
    showForm(2); 
  });

  document.getElementById('add-employee').addEventListener('click', function(event) {
    event.preventDefault(); 
  
    const employeeForm = document.getElementById('form-employee').querySelector('form');
    const formData = new FormData(employeeForm);
  
    fetch('/funcionario', {
      method: 'POST',
      body: formData
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Falha na submissão do formulário');
      }
      return response.json();
    })
    .then(data => {

      alert(data.message || 'Funcionário cadastrado com sucesso!');
      window.location.reload(); 
    })
    .catch(error => {
      console.error('Erro:', error);
      alert('Erro ao cadastrar funcionário.');
    });
  });

});

document.getElementById('add-sector').addEventListener('click', function() {
    var nomeSetor = document.getElementById('nome-setor').value; 
  
    fetch('/setor', {
      method: 'POST',
      body: JSON.stringify({ nome: nomeSetor }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => response.json())
    .then(data => {
      var setorId = data.setor_id;
  
      showForm(1);
    })
    .catch(error => {
      console.error('Erro:', error);
    });
  });

  document.getElementById('add-employee').addEventListener('click', function() {
    var primeiroNome = document.getElementById('primeiro-nome').value;
    var sobrenome = document.getElementById('sobrenome').value;
    var dataAdmissao = document.getElementById('data-admissao').value;
    var statusFuncionario = document.getElementById('status-funcionario').value;
    var idSetor = document.getElementById('id-setor').value;
    var idCargo = document.getElementById('id-cargo').value; 
  
    fetch('/funcionario', {
      method: 'POST',
      body: JSON.stringify({
        primeiro_nome: primeiroNome,
        sobrenome: sobrenome,
        data_admissao: dataAdmissao,
        status_funcionario: statusFuncionario,
        id_setor: idSetor,
        id_cargo: idCargo
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log('Funcionário adicionado com sucesso:', data);
    })
    .catch(error => {
      console.error('Erro ao adicionar funcionário:', error);
    });
  });

  window.addEventListener('DOMContentLoaded', (event) => {
    let currentFormIndex = 0;
    const forms = document.querySelectorAll('.form-section');
    const showForm = (index) => {
      forms[currentFormIndex].classList.remove('active');
      forms[index].classList.add('active');
      currentFormIndex = index;
    };
  
    showForm(currentFormIndex);
  
    const submitForm = (form, url, nextFormIndex) => {
      const formData = new FormData(form);
      fetch(url, {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Falha na submissão do formulário');
        }
        return response.json();
      })
      .then(data => {
        console.log(data);
        showForm(nextFormIndex);
      })
      .catch(error => {
        console.error('Erro:', error);
      });
    };
  
    const sectorForm = document.getElementById('form-sector').querySelector('form');
    sectorForm.addEventListener('submit', function(event) {
      event.preventDefault();
      submitForm(sectorForm, '/setor', 1);
    });
  
    const positionForm = document.getElementById('form-position').querySelector('form');
    positionForm.addEventListener('submit', function(event) {
      event.preventDefault();
      submitForm(positionForm, '/cargo', 2);
    });
  
    const employeeForm = document.getElementById('form-employee').querySelector('form');
    employeeForm.addEventListener('submit', function(event) {
      event.preventDefault();
      submitForm(employeeForm, '/funcionario', 3); 
    });
  });
  